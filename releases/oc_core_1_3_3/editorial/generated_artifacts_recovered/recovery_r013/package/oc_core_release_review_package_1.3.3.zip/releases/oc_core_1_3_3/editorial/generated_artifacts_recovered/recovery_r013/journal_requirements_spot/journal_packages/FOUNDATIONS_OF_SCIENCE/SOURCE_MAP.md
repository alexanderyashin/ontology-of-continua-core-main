# Source Map

Release SPOT hash: `7f5c80d9ac4383549100626e33c0cba8b26f51d6ecd5fe780bfee8f86175a41d`
Requirements matrix hash: `bfae6ada8dcdad1f0fd1c3dfba6c90b694a4ffa339263a647864bf32d9c64f7c`

## Reader Artifacts

- `release_guide` -> `releases/oc_core_1_3_3/editorial/generated_artifacts_recovered/recovery_r013/sources/release_guide_1.3.3.md`
- `master_monograph` -> `releases/oc_core_1_3_3/editorial/generated_artifacts_recovered/recovery_r013/b/base_source/oc_core_1_3_master_monograph.tex`
- `journal_core_article` -> `releases/oc_core_1_3_3/editorial/generated_artifacts_recovered/recovery_r013/sources/journal_core_article_1.3.3.md`
- `methods_repro_companion` -> `releases/oc_core_1_3_3/editorial/generated_artifacts_recovered/recovery_r013/sources/methods_repro_companion_1.3.3.md`
- `reviewer_attack_response_map` -> `releases/oc_core_1_3_3/editorial/generated_artifacts_recovered/recovery_r013/sources/reviewer_attack_response_map_1.3.3.md`
