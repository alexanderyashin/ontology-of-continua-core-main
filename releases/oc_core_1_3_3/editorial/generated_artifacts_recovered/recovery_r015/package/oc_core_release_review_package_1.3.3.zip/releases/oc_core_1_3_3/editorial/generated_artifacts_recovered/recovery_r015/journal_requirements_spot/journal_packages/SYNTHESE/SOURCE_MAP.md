# Source Map

Release SPOT hash: `d04733ece4f19e4ad00fbf7d4806a7776bcaef381a76108d5ab55b2eb5a1b320`
Requirements matrix hash: `a0a2399552cced6571d0def67800eb647c3633b24fe7ab376b01a41d89617bda`

## Reader Artifacts

- `release_guide` -> `releases/oc_core_1_3_3/editorial/generated_artifacts_recovered/recovery_r015/sources/release_guide_1.3.3.md`
- `master_monograph` -> `releases/oc_core_1_3_3/editorial/generated_artifacts_recovered/recovery_r015/b/base_source/oc_core_1_3_master_monograph.tex`
- `journal_core_article` -> `releases/oc_core_1_3_3/editorial/generated_artifacts_recovered/recovery_r015/sources/journal_core_article_1.3.3.md`
- `methods_repro_companion` -> `releases/oc_core_1_3_3/editorial/generated_artifacts_recovered/recovery_r015/sources/methods_repro_companion_1.3.3.md`
- `reviewer_attack_response_map` -> `releases/oc_core_1_3_3/editorial/generated_artifacts_recovered/recovery_r015/sources/reviewer_attack_response_map_1.3.3.md`
