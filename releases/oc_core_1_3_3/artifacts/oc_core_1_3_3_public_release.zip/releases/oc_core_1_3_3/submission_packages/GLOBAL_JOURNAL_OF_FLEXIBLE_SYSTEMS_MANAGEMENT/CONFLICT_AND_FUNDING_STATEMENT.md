# Conflict And Funding Statement: GLOBAL_JOURNAL_OF_FLEXIBLE_SYSTEMS_MANAGEMENT

Conflict-of-interest and funding declarations are owner-review placeholders for the owner-review package. They must be confirmed by the author before any journal submission.

Submission allowed: false.