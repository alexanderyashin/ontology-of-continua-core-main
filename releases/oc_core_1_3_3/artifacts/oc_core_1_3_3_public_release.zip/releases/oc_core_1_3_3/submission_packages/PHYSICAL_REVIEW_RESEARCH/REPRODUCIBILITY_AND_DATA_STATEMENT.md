# Reproducibility And Data Statement: PHYSICAL_REVIEW_RESEARCH

The release package includes checksum-bound source material, benchmark scripts, benchmark output hashes, claim/evidence maps, and release-machine scorecards. No private raw feedback or raw model output is included.

Primary reproducibility artifact: `releases/oc_core_1_3_3/artifacts/oc_core_1_3_3_owner_review_locked_release.zip`.
Journal submission remains `OWNER_REVIEW_LOCKED` until a separate owner-approved submission decision.