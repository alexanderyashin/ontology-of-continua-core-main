# Required Component Manifest: PHYSICAL_REVIEW_RESEARCH

- package_status: `OWNER_REVIEW_READY_FOR_OWNER_REVIEW`
- owner_review_locked: `true`
- submission_allowed: `false`

## Components

- `submission_package_json`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/PHYSICAL_REVIEW_RESEARCH/SUBMISSION_PACKAGE.json`
- `required_component_manifest_json`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/PHYSICAL_REVIEW_RESEARCH/REQUIRED_COMPONENT_MANIFEST.json`
- `required_component_manifest_md`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/PHYSICAL_REVIEW_RESEARCH/REQUIRED_COMPONENT_MANIFEST.md`
- `cover_letter`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/PHYSICAL_REVIEW_RESEARCH/COVER_LETTER_DRAFT.md`
- `checklist`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/PHYSICAL_REVIEW_RESEARCH/CHECKLIST.md`
- `reproducibility_and_data`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/PHYSICAL_REVIEW_RESEARCH/REPRODUCIBILITY_AND_DATA_STATEMENT.md`
- `ai_assistance`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/PHYSICAL_REVIEW_RESEARCH/AI_ASSISTANCE_DISCLOSURE.md`
- `conflict_and_funding`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/PHYSICAL_REVIEW_RESEARCH/CONFLICT_AND_FUNDING_STATEMENT.md`
- `venue_fit`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/PHYSICAL_REVIEW_RESEARCH/VENUE_FIT_VERDICT.md`