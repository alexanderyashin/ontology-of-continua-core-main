# Required Component Manifest: SYNTHESE

- package_status: `OWNER_REVIEW_READY_FOR_OWNER_REVIEW`
- owner_review_locked: `true`
- submission_allowed: `false`

## Components

- `submission_package_json`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/SYNTHESE/SUBMISSION_PACKAGE.json`
- `required_component_manifest_json`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/SYNTHESE/REQUIRED_COMPONENT_MANIFEST.json`
- `required_component_manifest_md`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/SYNTHESE/REQUIRED_COMPONENT_MANIFEST.md`
- `cover_letter`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/SYNTHESE/COVER_LETTER_DRAFT.md`
- `checklist`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/SYNTHESE/CHECKLIST.md`
- `reproducibility_and_data`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/SYNTHESE/REPRODUCIBILITY_AND_DATA_STATEMENT.md`
- `ai_assistance`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/SYNTHESE/AI_ASSISTANCE_DISCLOSURE.md`
- `conflict_and_funding`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/SYNTHESE/CONFLICT_AND_FUNDING_STATEMENT.md`
- `venue_fit`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/SYNTHESE/VENUE_FIT_VERDICT.md`