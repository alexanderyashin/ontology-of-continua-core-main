# AI Assistance Disclosure: ACS_OMEGA

AI tools assisted with editorial checking, release-machine automation, and structured review. The author remains responsible for claims, proofs, data, and final submission decisions.