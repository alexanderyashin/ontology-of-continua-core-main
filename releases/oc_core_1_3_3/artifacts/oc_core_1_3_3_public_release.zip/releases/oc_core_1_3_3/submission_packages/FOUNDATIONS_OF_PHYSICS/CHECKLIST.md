# Submission Checklist: FOUNDATIONS_OF_PHYSICS

- OWNER_REVIEW_LOCKED: true
- Submission allowed: false
- Owner approval required: true
- Manuscript PDF selected.
- Release DOI/reference to be inserted only after public release and separate owner approval.
- Data/code/reproducibility statement included.
- AI assistance disclosure included.
- Conflict/funding statements included.
- Required component manifest included.
- Artifact checksum references included in `SUBMISSION_PACKAGE.json`.
- Owner must approve submission separately.