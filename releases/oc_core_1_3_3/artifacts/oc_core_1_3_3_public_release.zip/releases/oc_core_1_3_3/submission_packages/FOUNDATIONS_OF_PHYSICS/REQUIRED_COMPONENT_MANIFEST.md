# Required Component Manifest: FOUNDATIONS_OF_PHYSICS

- package_status: `OWNER_REVIEW_READY_FOR_OWNER_REVIEW`
- owner_review_locked: `true`
- submission_allowed: `false`

## Components

- `submission_package_json`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/FOUNDATIONS_OF_PHYSICS/SUBMISSION_PACKAGE.json`
- `required_component_manifest_json`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/FOUNDATIONS_OF_PHYSICS/REQUIRED_COMPONENT_MANIFEST.json`
- `required_component_manifest_md`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/FOUNDATIONS_OF_PHYSICS/REQUIRED_COMPONENT_MANIFEST.md`
- `cover_letter`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/FOUNDATIONS_OF_PHYSICS/COVER_LETTER_DRAFT.md`
- `checklist`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/FOUNDATIONS_OF_PHYSICS/CHECKLIST.md`
- `reproducibility_and_data`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/FOUNDATIONS_OF_PHYSICS/REPRODUCIBILITY_AND_DATA_STATEMENT.md`
- `ai_assistance`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/FOUNDATIONS_OF_PHYSICS/AI_ASSISTANCE_DISCLOSURE.md`
- `conflict_and_funding`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/FOUNDATIONS_OF_PHYSICS/CONFLICT_AND_FUNDING_STATEMENT.md`
- `venue_fit`: `READY_FOR_OWNER_REVIEW` - `releases/oc_core_1_3_3/submission_packages/FOUNDATIONS_OF_PHYSICS/VENUE_FIT_VERDICT.md`