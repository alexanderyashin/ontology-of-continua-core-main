# OC Core 1.3.3 Public Payload Suitability

State: `PASS`
Failures: `0`
Public ZIP: `releases/oc_core_1_3_3/artifacts/oc_core_1_3_3_public_release.zip`
Public ZIP SHA-256: `0acbbf9d66bece1fd6a1e2daa3627b2581e5f2964fe267f1ffab31e591609304`

| PDF | State | Pages | Text chars | Size |
| --- | --- | ---: | ---: | ---: |
| `OC_CORE_1_3_3_MASTER_MONOGRAPH_EN.pdf` | `PASS` | 706 | 1440269 | 2685920 |
| `OC_CORE_1_3_3_JOURNAL_CORE_EN.pdf` | `PASS` | 16 | 54282 | 86231 |
| `OC_CORE_1_3_3_METHODS_AND_REPRODUCIBILITY_COMPANION_EN.pdf` | `PASS` | 31 | 50771 | 92699 |
| `OC_CORE_1_3_3_REVIEWER_ATTACK_AND_RESPONSE_MAP_EN.pdf` | `PASS` | 31 | 79272 | 120807 |
