# OC Core 1.3.2 Owner Approval Packet

Status: RELEASE_READY_NO_SEND.

Artifact freeze hash: `141ea4dcfdec2c0b648b6a6e76b9ca5c553adfe6d65d224a3dce52e2d9f73794`
Owner approval required: true.
Owner approved: false.
Publish allowed: false.
Global no-send lock: true.

Owner must review the public release dossier and approve the exact freeze hash before any tag or upload.
