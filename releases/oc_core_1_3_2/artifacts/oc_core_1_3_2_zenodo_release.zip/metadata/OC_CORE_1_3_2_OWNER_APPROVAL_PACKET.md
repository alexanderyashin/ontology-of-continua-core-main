# OC Core 1.3.2 Owner Approval Packet

Status: RELEASE_READY_NO_SEND.

Artifact freeze hash: `abab34cdb36347e151d27e25f2cbbfe9ebeae3834a28d093fd9848d6d1b67aa4`
Owner approval required: true.
Owner approved: false.
Publish allowed: false.
Global no-send lock: true.

Release quality failure analysis: `releases/oc_core_1_3_2/editorial/OC_CORE_1_3_2_RELEASE_QUALITY_FAILURE_ANALYSIS.md`.
Acknowledgement registry: `releases/oc_core_1_3_2/editorial/OC_CORE_1_3_2_ACKNOWLEDGEMENT_REGISTRY.md`.

Owner must review the public release dossier and approve the exact freeze hash before any tag or upload.
