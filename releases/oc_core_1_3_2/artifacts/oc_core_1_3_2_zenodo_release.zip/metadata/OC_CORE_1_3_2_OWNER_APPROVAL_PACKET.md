# OC Core 1.3.2 Owner Approval Packet

Status: RELEASE_READY_NO_SEND.

Artifact freeze hash: `1069aa0f858a191662293cff018e4edc38de649fa6bad9901a91d776fe7fa420`
Owner approval required: true.
Owner approved: false.
Publish allowed: false.
Global no-send lock: true.

Owner must review the public release dossier and approve the exact freeze hash before any tag or upload.
