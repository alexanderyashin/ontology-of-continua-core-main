# OC Core 1.3.2 Owner Approval Packet

Status: RELEASE_READY_NO_SEND.

Artifact freeze hash: `d4be884accdd1dae39a9a250a9380bd122fb696867023a9e60b41bc338ca7864`
Owner approval required: true.
Owner approved: false.
Publish allowed: false.
Global no-send lock: true.

Owner must review the public release dossier and approve the exact freeze hash before any tag or upload.
