# OC Core 1.3.2 Owner Approval Packet

Status: RELEASE_READY_NO_SEND.

Artifact freeze hash: `aff9d67aedc4279334792fb278ff96dab8ad85eb1236b9ad3db878388ffaeeb8`
Owner approval required: true.
Owner approved: false.
Publish allowed: false.
Global no-send lock: true.

Owner must review the public release dossier and approve the exact freeze hash before any tag or upload.
