# OC Core 1.3.2 Owner Approval Packet

Status: RELEASE_READY_NO_SEND.

Artifact freeze hash: `035c65b018bf6ceced8f4a05cdf28c98298e2b948ff01077fc8405a418839c8a`
Owner approval required: true.
Owner approved: false.
Publish allowed: false.
Global no-send lock: true.

Owner must review the public release dossier and approve the exact freeze hash before any tag or upload.
