# Public Manuscript Staging Queue

Queue total: `46`

All rows are appendix/frontier/support candidates only. External publication remains locked.

| Packet | Role | State |
| --- | --- | --- |
| `autopilot_feature_candidates_r3_mechanism_candid_60a60195` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `autopilot_feature_candidates_r3_mechanism_candid_72f9f899` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `autopilot_feature_candidates_r3_mechanism_candid_bdd8de38` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_01_alternative_group_action_in_topos_quantum_d0ed03ee` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_01_broken_symmetries_and_the_masses_of_gauge_35bfce67` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_04_conservation_of_isotopic_spin_and_isotopic_c0ed10e9` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_04_determinism_and_indeterminism_as_model_art_9f141552` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_07_encoding_curved_tetrahedra_in_face_holonom_801dd90a` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_10_how_to_account_for_quantum_non_locality_on_3df893b6` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_13_loop_quantum_gravity_5ca7c043` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_16_no_categorial_support_for_radical_ontic_st_720d118a` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_190906_causal_dynamical_triangulations_and_the_qu_5601c7b3` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_19_quantum_bayesianism_a_study_5d9c3891` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_22_relational_quantum_dynamics_rqd_an_informa_4bf99cb7` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_298294_determinism_and_indeterminism_as_model_art_b07d8cf1` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_298297_lectures_on_holographic_non_fermi_liquids_dd9e0d83` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_298300_realism_and_ontology_in_quantum_mechanics_f4eff7f3` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_298303_emergent_gravity_as_the_eraser_of_anomalou_c851b4a9` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_298306_no_categorial_support_for_radical_ontic_st_18d45d56` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_298309_no_categorial_support_for_radical_ontic_st_0c7d2563` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_298312_remarks_on_the_sachdev_ye_kitaev_model_d8d0bbc7` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_298330_how_to_account_for_quantum_non_locality_on_609fc719` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_405790_conservation_of_isotopic_spin_and_isotopic_7d677311` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_405793_emergent_gravity_as_the_eraser_of_anomalou_9b6a45bf` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_415036_broken_symmetries_and_the_masses_of_gauge_b2300790` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_415039_doering_isham_topos_theory_in_the_foundati_25dfc7e7` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_499039_broken_symmetries_and_the_masses_of_gauge_1f89bb1e` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_499042_doering_isham_topos_theory_in_the_foundati_790c3bfd` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521506_conservation_of_isotopic_spin_and_isotopic_e4906c8b` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521509_emergent_gravity_as_the_eraser_of_anomalou_9b28160e` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521512_group_action_in_topos_quantum_theory_5d5a38c4` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521515_logic_of_propositions_in_topos_quantum_the_ef295291` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521518_new_approach_to_nonrelativistic_diffeomorp_aeafbdbf` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521521_probabilities_in_topos_quantum_theory_d9bf8f79` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521524_reality_contextuality_and_probability_in_q_089c5d7c` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521527_space_time_as_a_causal_set_99c9a9e9` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521530_the_topology_of_the_quantum_vacuum_e915f105` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521533_topos_theory_and_neo_realist_quantum_theor_3650293d` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521536_causal_dynamical_triangulations_and_the_qu_1f0124b4` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521539_doering_isham_topos_theory_in_the_foundati_a1e8b68f` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521542_extending_the_topos_quantum_theory_approac_415bd8e1` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521545_lectures_on_holographic_non_fermi_liquids_6239762e` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521548_modality_and_contextuality_in_topos_quantu_5cc03750` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521551_phenomenology_of_mml_math_xmlns_mml_http_w_04014d38` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `institute_521554_realism_and_ontology_in_quantum_mechanics_3bd79e9d` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
| `k0_structural_realist_extension` | appendix/frontier/support | `NO_SEND_OWNER_REVIEW` |
